/**
 * Classe para testar a classe Livro.
 */
public class TestarLivros {
    /**
     * Método principal para testar a classe Livro.
     *
     * @param args os argumentos da linha de comando (não utilizados neste exemplo)
     */
    public static void main(String[] args) {
        // Criando um objeto livrofavorito do tipo Livro
        Livro livrofavorito = new Livro();

        // Alterando os atributos do livrofavorito
        livrofavorito.setTitulo("O Pequeno Príncipe");
        livrofavorito.setQtdPaginas(98);

        // Escrevendo na tela as informações do livrofavorito
        System.out.println("O livro " + livrofavorito.getTitulo() + " possui " + livrofavorito.getQtdPaginas() + " páginas");

        // Alterando a quantidade de páginas lidas e verificando o progresso
        livrofavorito.setPaginasLidas(20);
        livrofavorito.verificarProgresso();

        livrofavorito.setPaginasLidas(50);
        livrofavorito.verificarProgresso();

        // Instanciando outros 10 livros
        Livro[] outrosLivros = new Livro[10];
        for (int i = 0; i < outrosLivros.length; i++) {
            outrosLivros[i] = new Livro("Livro " + (i + 1), 100); // Exemplo: todos os outros livros têm 100 páginas
        }

        // Testando os métodos para os outros livros
        for (Livro livro : outrosLivros) {
            System.out.println("Livro: " + livro.getTitulo());
            System.out.println("Páginas: " + livro.getQtdPaginas());
            livro.verificarProgresso();
        }
    }
}

