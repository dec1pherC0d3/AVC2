/**
 * Classe que representa um livro.
 */
public class Livro {
    private String titulo; // Título do livro
    private int qtdPaginas; // Quantidade total de páginas do livro
    private int paginasLidas; // Quantidade de páginas lidas do livro

    // Construtores

    /**
     * Construtor padrão.
     */
    public Livro() {
    }

    /**
     * Construtor que inicializa o título e a quantidade de páginas do livro.
     *
     * @param titulo     o título do livro
     * @param qtdPaginas a quantidade de páginas do livro
     */
    public Livro(String titulo, int qtdPaginas) {
        this.titulo = titulo;
        this.qtdPaginas = qtdPaginas;
    }

    // Getters e Setters

    /**
     * Obtém o título do livro.
     *
     * @return o título do livro
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Define o título do livro.
     *
     * @param titulo o título do livro
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * Obtém a quantidade total de páginas do livro.
     *
     * @return a quantidade total de páginas do livro
     */
    public int getQtdPaginas() {
        return qtdPaginas;
    }

    /**
     * Define a quantidade total de páginas do livro.
     *
     * @param qtdPaginas a quantidade total de páginas do livro
     */
    public void setQtdPaginas(int qtdPaginas) {
        this.qtdPaginas = qtdPaginas;
    }

    /**
     * Obtém a quantidade de páginas lidas do livro.
     *
     * @return a quantidade de páginas lidas do livro
     */
    public int getPaginasLidas() {
        return paginasLidas;
    }

    /**
     * Define a quantidade de páginas lidas do livro.
     *
     * @param paginasLidas a quantidade de páginas lidas do livro
     */
    public void setPaginasLidas(int paginasLidas) {
        this.paginasLidas = paginasLidas;
    }

    // Método para verificar o progresso da leitura

    /**
     * Verifica o progresso da leitura do livro e imprime a porcentagem lida.
     */
    public void verificarProgresso() {
        double porcentagem = (double) paginasLidas * 100 / qtdPaginas;
        System.out.println("Você já leu " + porcentagem + " por cento do livro");
    }
}

