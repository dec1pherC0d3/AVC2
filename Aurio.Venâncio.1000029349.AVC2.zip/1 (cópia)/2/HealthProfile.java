import java.util.Calendar;
import java.util.Scanner;

/**
 * Classe que representa o perfil de saúde de uma pessoa.
 */
public class HealthProfile {
    private String nome;
    private String sobrenome;
    private char sexo;
    private int diaNascimento;
    private int mesNascimento;
    private int anoNascimento;
    private double altura; // em metros
    private double peso; // em quilogramas

    /**
     * Construtor da classe HealthProfile.
     *
     * @param nome           O primeiro nome da pessoa.
     * @param sobrenome      O sobrenome da pessoa.
     * @param sexo           O sexo da pessoa (M ou F).
     * @param diaNascimento  O dia de nascimento da pessoa.
     * @param mesNascimento  O mês de nascimento da pessoa.
     * @param anoNascimento  O ano de nascimento da pessoa.
     * @param altura         A altura da pessoa em metros.
     * @param peso           O peso da pessoa em quilogramas.
     */
    public HealthProfile(String nome, String sobrenome, char sexo, int diaNascimento, int mesNascimento, int anoNascimento, double altura, double peso) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.sexo = sexo;
        this.diaNascimento = diaNascimento;
        this.mesNascimento = mesNascimento;
        this.anoNascimento = anoNascimento;
        this.altura = altura;
        this.peso = peso;
    }

    // Getters e setters

    // Getter do nome
    public String getNome() {
        return nome;
    }

    // Setter do nome
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Getter do sobrenome
    public String getSobrenome() {
        return sobrenome;
    }

    // Setter do sobrenome
    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    // Getter do sexo
    public char getSexo() {
        return sexo;
    }

    // Setter do sexo
    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    // Getter do dia de nascimento
    public int getDiaNascimento() {
        return diaNascimento;
    }

    // Setter do dia de nascimento
    public void setDiaNascimento(int diaNascimento) {
        this.diaNascimento = diaNascimento;
    }

    // Getter do mês de nascimento
    public int getMesNascimento() {
        return mesNascimento;
    }

    // Setter do mês de nascimento
    public void setMesNascimento(int mesNascimento) {
        this.mesNascimento = mesNascimento;
    }

    // Getter do ano de nascimento
    public int getAnoNascimento() {
        return anoNascimento;
    }

    // Setter do ano de nascimento
    public void setAnoNascimento(int anoNascimento) {
        this.anoNascimento = anoNascimento;
    }

    // Getter da altura
    public double getAltura() {
        return altura;
    }

    // Setter da altura
    public void setAltura(double altura) {
        this.altura = altura;
    }

    // Getter do peso
    public double getPeso() {
        return peso;
    }

    // Setter do peso
    public void setPeso(double peso) {
        this.peso = peso;
    }

    // Métodos de cálculo

    /**
     * Calcula a idade da pessoa com base na data de nascimento.
     *
     * @return A idade da pessoa em anos.
     */
    public int calcularIdade() {
        Calendar dataAtual = Calendar.getInstance();
        int anoAtual = dataAtual.get(Calendar.YEAR);
        int idade = anoAtual - anoNascimento;

        // Verificar se já fez aniversário no ano atual
        Calendar dataNascimento = Calendar.getInstance();
        dataNascimento.set(anoAtual, mesNascimento - 1, diaNascimento); // Mês começa de 0
        if (dataNascimento.after(dataAtual)) {
            idade--;
        }

        return idade;
    }

    /**
     * Calcula o índice de massa corporal (IMC) da pessoa.
     *
     * @return O índice de massa corporal (IMC) da pessoa.
     */
    public double calcularIMC() {
        return peso / (altura * altura);
    }

    /**
     * Calcula a frequência cardíaca máxima da pessoa.
     *
     * @return A frequência cardíaca máxima da pessoa.
     */
    public int calcularFrequenciaCardiacaMaxima() {
        return 220 - calcularIdade();
    }

    /**
     * Calcula a frequência cardíaca mínima alvo da pessoa.
     *
     * @return A frequência cardíaca mínima alvo da pessoa.
     */
    public int calcularFrequenciaCardiacaAlvoMinima() {
        return (int) (calcularFrequenciaCardiacaMaxima() * 0.5);
    }

    /**
     * Calcula a frequência cardíaca máxima alvo da pessoa.
     *
     * @return A frequência cardíaca máxima alvo da pessoa.
     */
    public int calcularFrequenciaCardiacaAlvoMaxima() {
        return (int) (calcularFrequenciaCardiacaMaxima() * 0.85);
    }

    /**
     * Método principal que solicita as informações da pessoa, cria um objeto HealthProfile e imprime suas informações.
     *
     * @param args Os argumentos da linha de comando (não utilizados).
     */
    public static void main(String[] args) {
        // Solicitar informações da pessoa
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o nome: ");
        String nome = scanner.nextLine();
        System.out.println("Digite o sobrenome: ");
        String sobrenome = scanner.nextLine();
        System.out.println("Digite o sexo (M/F): ");
        char sexo = scanner.next().charAt(0);
        System.out.println("Digite o dia de nascimento: ");
        int diaNascimento = scanner.nextInt();
        System.out.println("Digite o mês de nascimento: ");
        int mesNascimento = scanner.nextInt();
        System.out.println("Digite o ano de nascimento: ");
        int anoNascimento = scanner.nextInt();
        System.out.println("Digite a altura (em metros): ");
        double altura = scanner.nextDouble();
        System.out.println("Digite o peso (em quilogramas): ");
        double peso = scanner.nextDouble();

        // Instanciar objeto HealthProfile
        HealthProfile pessoa = new HealthProfile(nome, sobrenome, sexo, diaNascimento, mesNascimento, anoNascimento, altura, peso);

        // Imprimir informações
        System.out.println("Nome: " + pessoa.getNome() + " " + pessoa.getSobrenome());
        System.out.println("Sexo: " + pessoa.getSexo());
        System.out.println("Data de Nascimento: " + pessoa.getDiaNascimento() + "/" + pessoa.getMesNascimento() + "/" + pessoa.getAnoNascimento());
        System.out.println("Idade: " + pessoa.calcularIdade() + " anos");
        System.out.printf("IMC: %.2f\n", pessoa.calcularIMC());
        System.out.println("Intervalo de Frequência Cardíaca Máxima: " + pessoa.calcularFrequenciaCardiacaAlvoMinima() + " - " + pessoa.calcularFrequenciaCardiacaAlvoMaxima() + " bpm");
    }
}

