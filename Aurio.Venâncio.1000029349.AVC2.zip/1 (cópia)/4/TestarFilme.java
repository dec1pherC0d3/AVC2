/**
 * Classe de teste para a classe Filme.
 */
public class TestarFilme {
    /**
     * Método principal para testar a classe Filme.
     *
     * @param args Os argumentos da linha de comando (não utilizados neste caso).
     */
    public static void main(String[] args) {
        // Criando objeto filme1 do tipo Filme
        Filme filme1 = new Filme();
        filme1.setTitulo("Os Vingadores");
        filme1.setDuracaoEmMinutos(142);
        filme1.exibirDuracaoEmHoras();

        // Criando objeto filme2 do tipo Filme
        Filme filme2 = new Filme("Hotel Transilvânia", 93);
        filme2.exibirDuracaoEmHoras();

        // Exibindo os filmes em cartaz
        System.out.println("Os filmes em cartaz são " + filme1.getTitulo() + " e " + filme2.getTitulo());
    }
}

