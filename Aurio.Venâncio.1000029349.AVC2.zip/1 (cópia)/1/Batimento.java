import java.util.Calendar;
import java.util.Scanner;

/**
 * Classe que representa informações sobre batimentos cardíacos.
 */
public class Batimento {
    private String nome;
    private String sobrenome;
    private int diaNascimento;
    private int mesNascimento;
    private int anoNascimento;

    /**
     * Construtor da classe Batimento.
     * 
     * @param nome          O nome da pessoa.
     * @param sobrenome     O sobrenome da pessoa.
     * @param diaNascimento O dia de nascimento da pessoa.
     * @param mesNascimento O mês de nascimento da pessoa.
     * @param anoNascimento O ano de nascimento da pessoa.
     */
    public Batimento(String nome, String sobrenome, int diaNascimento, int mesNascimento, int anoNascimento) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.diaNascimento = diaNascimento;
        this.mesNascimento = mesNascimento;
        this.anoNascimento = anoNascimento;
    }

    /**
     * Método getter para o nome da pessoa.
     * 
     * @return O nome da pessoa.
     */
    public String getNome() {
        return nome;
    }

    /**
     * Método getter para o sobrenome da pessoa.
     * 
     * @return O sobrenome da pessoa.
     */
    public String getSobrenome() {
        return sobrenome;
    }

    /**
     * Método getter para o dia de nascimento da pessoa.
     * 
     * @return O dia de nascimento da pessoa.
     */
    public int getDiaNascimento() {
        return diaNascimento;
    }

    /**
     * Método getter para o mês de nascimento da pessoa.
     * 
     * @return O mês de nascimento da pessoa.
     */
    public int getMesNascimento() {
        return mesNascimento;
    }

    /**
     * Método getter para o ano de nascimento da pessoa.
     * 
     * @return O ano de nascimento da pessoa.
     */
    public int getAnoNascimento() {
        return anoNascimento;
    }

    /**
     * Construtor da classe Batimento que solicita as informações do usuário.
     */
    public Batimento() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o nome: ");
        this.nome = scanner.nextLine();
        System.out.println("Digite o sobrenome: ");
        this.sobrenome = scanner.nextLine();
        System.out.println("Digite o dia de nascimento: ");
        this.diaNascimento = Integer.parseInt(scanner.nextLine());
        System.out.println("Digite o mês de nascimento: ");
        this.mesNascimento = Integer.parseInt(scanner.nextLine());
        System.out.println("Digite o ano de nascimento: ");
        this.anoNascimento = Integer.parseInt(scanner.nextLine());
    }

    /**
     * Calcula a idade da pessoa com base na data atual.
     * 
     * @return Idade da pessoa.
     */
    public int calcularIdade() {
        Calendar dataAtual = Calendar.getInstance();
        int anoAtual = dataAtual.get(Calendar.YEAR);
        int idade = anoAtual - anoNascimento;

        // Verificar se já fez aniversário no ano atual
        Calendar dataNascimento = Calendar.getInstance();
        dataNascimento.set(anoAtual, mesNascimento - 1, diaNascimento); // Mês começa de 0
        if (dataNascimento.after(dataAtual)) {
            idade--;
        }

        return idade;
    }

    /**
     * Calcula a frequência cardíaca máxima da pessoa.
     * 
     * @return Frequência cardíaca máxima.
     */
    public int calcularFrequenciaCardiacaMaxima() {
        return 220 - calcularIdade();
    }

    /**
     * Calcula a frequência cardíaca alvo mínima da pessoa.
     * 
     * @return Frequência cardíaca alvo mínima.
     */
    public int calcularFrequenciaCardiacaAlvoMinima() {
        return (int) (calcularFrequenciaCardiacaMaxima() * 0.5);
    }

    /**
     * Calcula a frequência cardíaca alvo máxima da pessoa.
     * 
     * @return Frequência cardíaca alvo máxima.
     */
    public int calcularFrequenciaCardiacaAlvoMaxima() {
        return (int) (calcularFrequenciaCardiacaMaxima() * 0.85);
    }

    /**
     * Método principal para teste da classe.
     * 
     * @param args Argumentos da linha de comando (não utilizado).
     */
    public static void main(String[] args) {
        // Exemplo de uso
        Batimento pessoa = new Batimento();
        System.out.println("Nome: " + pessoa.getNome() + " " + pessoa.getSobrenome());
        System.out.println("Data de Nascimento: " + pessoa.getDiaNascimento() + "/" + pessoa.getMesNascimento() + "/" + pessoa.getAnoNascimento());
        System.out.println("Idade: " + pessoa.calcularIdade() + " anos");
        System.out.println("Frequência Cardíaca Máxima: " + pessoa.calcularFrequenciaCardiacaMaxima() + " bpm");
        System.out.println("Frequência Cardíaca Alvo: " + pessoa.calcularFrequenciaCardiacaAlvoMinima() + " - " + pessoa.calcularFrequenciaCardiacaAlvoMaxima() + " bpm");
    }
}

